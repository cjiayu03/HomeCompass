# Design-to-code crosswalk

**Baseline:** main 3639c5c, 26 October 2026. Target services can map to functions or components; actual source signatures are authoritative.

| Design responsibility | Current implementation | Contract and limits |
|---|---|---|
| ApplicationBootstrap | main.py lifespan, migrations.py, readiness.py, app/providers.jsx | Pool lifecycle and schema readiness; unavailable persistence is explicit. |
| UserAccount / LocalIdentity / LocalSession / LocalAuthGateway | local_auth.py, security.py, database.py; auth routes and auth-provider.jsx | Argon2id passwords, hashed session tokens, cookie/origin checks, password change and transactional local deletion. |
| FamilyProfile / HouseholdMember / SupportNeed | profile schemas/routes; onboarding-flow.jsx | Household intent and preferences persisted through profile; normalized domain objects are not all separate UI services. |
| SearchController / FilterCriteria / SearchResultPage | main.py search routes; schemas.py, pagination.py, search-workbench.jsx | Validated filters, real counts, source metadata and pagination; unsupported evidence stays unavailable. |
| ScoringService / CriterionScore / ScoringResult | scoring.py, score-breakdown.jsx | home-fit-v1 component score/coverage; separate loaded-record scenario preview. Policy acceptance remains open. |
| ShortlistService / ComparisonService | shortlist routes, workspace-provider.jsx, compare page | Owner-scoped writes, durable selected-record lookup, comparison of 2-3 distinct homes. |
| SavedSearch / SearchHistoryEntry | saved_searches.py, history routes, saved-searches.jsx | Named criteria can be rerun; full automatic history UI remains incomplete. |
| PlanningWorkspace / Scenario / DecisionRecord / PlanningService | planning.py, schemas.py, planning-provider.jsx, decision-board.jsx | Revision-checked account text storage, explicit HTTP 409, local edit retention; photos stay in IndexedDB. |
| Decision summary / market view | decision-summary.jsx, market-explorer.jsx, market/history route | Printable/HTML summary and monthly transaction evidence; no photo export or forecast. |
| PersonalPlace / MapRoutingGateway | onemap.py, places routes, place-picker.jsx, place-manager.jsx | Provider-backed suggestions and selected locations; straight-line distances, no journey-time implementation. |
| DatasetSnapshot / GovernmentDataGateway / DataIngestionService | sources/ modules, source/resource routes | Bounded validated imports with source/provenance; runtime database not bundled. |
| AIInterpretationService / GeminiInteractionsGateway | ai.py and AI routes | Schema-constrained interpretation/evidence summaries, budget gating; live execution not claimed. |
| WorkspaceState / ExploreView / AccountView | workspace-provider.jsx, app workspace routes, map-view.jsx, map-3d-view.jsx | Shared selected-home state, map fallback, account boundaries and visible unavailable states. |

The design also retains route estimates, policy/fee joins and other future requirements. Remaining target classes must not be read as proof of implementation. Original AI exercise files retain their prompt-time provider design and are deliberately distinct from this current source snapshot.
