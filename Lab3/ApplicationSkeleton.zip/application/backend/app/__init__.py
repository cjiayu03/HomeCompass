"""HomeCompass application package."""
