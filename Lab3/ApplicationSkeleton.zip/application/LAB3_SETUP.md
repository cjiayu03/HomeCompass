# Lab 3 application setup

Source baseline: main `3639c5c5bce9e88ac8adcda4b73ec19266eb0327`, inspected 26 October 2026. Source files are unchanged; BASELINE.json supplies their hashes. This is the refined prototype, separate from OriginalAISkeleton.zip.

## Install and run

Use the Node version expected by Next.js 16 (the baseline CI uses Node 22) and Python 3.12 as recorded in backend/.python-version. From application/:

```bash
npm ci
python3 -m venv .venv
.venv/bin/python -m pip install -r backend/requirements.txt
cp .env.example .env
```

Configure DATABASE_URL for a local PostGIS database, exact CORS origins and the API/frontend origins. Follow ops/README.md for native PostGIS or Docker Compose. All migrations 001-010 must be applied before private operations; /ready checks schema readiness. The native launcher uses npm run local. No imported data or credentials are bundled.

For separate processes, start the API from backend/ with the installed Python environment, then run npm run dev from application/. Keep browser/API hostnames consistent for cookie authentication. For a production-mode local build:

```bash
NEXT_PUBLIC_API_BASE_URL=http://localhost:8000 npm run build
npm run start
```

Set AUTH_COOKIE_SECURE=true behind HTTPS. Accounts are local email/password; Supabase/Google sign-in is not supported. Import public data and run geocoding using backend/README.md. Gemini is disabled until credentials, rates and a positive budget are configured.

