import { cn } from '@/lib/utils';

export function Input({ className, type = 'text', ...props }) {
  return <input type={type} className={cn('flex h-11 w-full rounded-lg border bg-background px-3.5 py-2 text-sm text-foreground placeholder:text-muted-foreground transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium disabled:cursor-not-allowed disabled:opacity-50', className)} {...props} />;
}
