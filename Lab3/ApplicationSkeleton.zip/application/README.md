# HomeCompass - Lab 3 prototype

Source baseline: softwarelab3/2006-SCSL-S1 main 3639c5c, reviewed 26 October 2026.

Start with [LAB3_SETUP.md](LAB3_SETUP.md) for dependencies, local PostGIS, migration and run instructions. [DESIGN_CROSSWALK.md](DESIGN_CROSSWALK.md) maps the design to public source interfaces. [BASELINE.json](BASELINE.json) inventories the unchanged upstream files.

The frontend uses Next.js/React and JavaScript; the backend uses Python/FastAPI with PostgreSQL/PostGIS. Accounts use local passwords and database-backed session cookies. Apply migrations 001-010 before private operations. Native and Docker setup are documented in [ops/README.md](ops/README.md); API/import instructions are in [backend/README.md](backend/README.md).

This in-progress prototype includes source, tests and dependency manifests. Live credentials, imported database records, dependencies and build caches are excluded. Current architecture and remaining target behavior are documented in ../SystemArchitecture.md.

README.md, LAB3_SETUP.md, DESIGN_CROSSWALK.md and BASELINE.json are submission documentation. OriginalAISkeleton.zip is a separate historical AI artifact; this prototype is not presented as a later chronological edit of that output.
