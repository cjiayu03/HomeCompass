# TODO: Accept two or three unique entries; reject one, four, duplicates and unauthorized IDs.
