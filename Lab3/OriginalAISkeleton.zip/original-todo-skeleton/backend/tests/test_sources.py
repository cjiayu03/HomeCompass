# TODO: Reject malformed imports; preserve last-valid snapshots and freshness metadata.
