# TODO: PersonalPlace and PersonalPlaceRule: owner, coordinate, operator, units and mode.
