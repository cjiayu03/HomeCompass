# TODO: CriterionWeight, GeoPoint and RouteEstimate: validation, units and unavailable status.
