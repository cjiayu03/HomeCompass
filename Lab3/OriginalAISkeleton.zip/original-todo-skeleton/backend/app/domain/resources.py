# TODO: NeighbourhoodResource and DatasetSnapshot: resource geometry, freshness and source.
