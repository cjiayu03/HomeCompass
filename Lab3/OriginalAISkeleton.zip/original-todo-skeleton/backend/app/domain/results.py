# TODO: SearchResult, SearchResultPage, CriterionScore and ScoringResult: collection and coverage.
