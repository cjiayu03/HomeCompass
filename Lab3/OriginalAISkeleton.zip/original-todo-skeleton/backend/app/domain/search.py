# TODO: SearchRequest, FilterCriteria and SearchHistoryEntry: replayable canonical request.
