# TODO: Shortlist and ShortlistEntry: valid empty collections and unique ordered membership.
