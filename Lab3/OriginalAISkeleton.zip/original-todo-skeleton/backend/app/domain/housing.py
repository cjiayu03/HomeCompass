# TODO: CandidateHome: dated historical price observation and verified coordinate provenance.
