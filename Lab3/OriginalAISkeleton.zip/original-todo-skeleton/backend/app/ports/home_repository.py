# TODO: HomeRepository interface responsibility: find candidates and resolve IDs.
