# TODO: MapRoutingGateway: batch/interactive geocoding, routes, units, provenance and unavailable state.
