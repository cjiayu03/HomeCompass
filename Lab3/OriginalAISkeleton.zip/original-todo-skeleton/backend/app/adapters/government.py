# TODO: GovernmentDataGateway: bounded downloads, schema validation and isolated source failures.
