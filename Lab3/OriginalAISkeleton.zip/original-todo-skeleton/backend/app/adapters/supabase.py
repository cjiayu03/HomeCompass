# TODO: SupabaseAuthGateway: server verification, OAuth callback and provider account deletion.
