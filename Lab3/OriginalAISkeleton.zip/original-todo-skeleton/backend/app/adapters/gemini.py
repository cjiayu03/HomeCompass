# TODO: GeminiInteractionsGateway: constrained interpretation/evidence summaries with key/budget gates.
