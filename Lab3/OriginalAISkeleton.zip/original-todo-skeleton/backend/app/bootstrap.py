# TODO: ApplicationBootstrap: load configuration, initialize providers/pool, register routes and clean up.
