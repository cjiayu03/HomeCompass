# TODO: Validated HTTP boundary: ownership, status codes and typed request/response contracts.
