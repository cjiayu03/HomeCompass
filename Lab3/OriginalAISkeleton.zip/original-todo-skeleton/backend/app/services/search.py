# TODO: SearchController: one canonical search pipeline and honest zero/few/many results.
