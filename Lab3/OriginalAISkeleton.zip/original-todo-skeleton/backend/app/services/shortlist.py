# TODO: ShortlistService: owner-scoped idempotent save/remove/reorder and criterion sort.
