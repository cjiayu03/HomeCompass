# TODO: DataIngestionService: stage, validate and atomically publish per-source snapshots.
