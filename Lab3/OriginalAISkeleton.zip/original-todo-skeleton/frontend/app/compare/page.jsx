// TODO: Comparison boundary: exactly two or three unique selected homes and aligned evidence.
