// TODO: SupabaseAuthGateway callback boundary: validate state and restore pending action.
