// TODO: ApplicationBootstrap: initialize configurable app name and shared WorkspaceState.
