// TODO: Shortlist boundary: save, remove, reorder and sort with owner isolation.
