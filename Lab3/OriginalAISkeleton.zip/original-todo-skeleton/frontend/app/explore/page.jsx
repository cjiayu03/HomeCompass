// TODO: ExploreView: map, structured and natural-language modes, filters, evidence and result status.
