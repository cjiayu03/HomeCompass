// TODO: AccountView: profile, logout and confirmed retryable deletion.
