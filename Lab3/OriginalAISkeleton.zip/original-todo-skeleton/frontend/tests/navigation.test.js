// TODO: Verify dialog-map transitions, keyboard actions and modal return paths.
