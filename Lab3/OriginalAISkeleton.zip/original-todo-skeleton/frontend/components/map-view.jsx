// TODO: Map boundary: geocoded homes, resources, owned places and accessible map actions.
