// TODO: WorkspaceState: canonical criteria, family setup, weights, history and mode transfer.
